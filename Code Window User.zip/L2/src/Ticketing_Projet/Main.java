package Ticketing_Projet;

import javax.swing.*;

public class Main {

	public static void main(String[] args) {
		Window_User w = new Window_User();

	}

}
